// JavaScript Document

function header(){
document.write('<div id="">');
document.write("메뉴부분 HTML");
document.write("</div");
}